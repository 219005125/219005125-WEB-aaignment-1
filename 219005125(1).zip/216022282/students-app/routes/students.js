var express = require('express');
var router = express.Router();

//try
var names = [
  {
    name: 'Chris_Martin',
    DOB: '1990-06-15',
    programme: 'LLB',
    level: '300',
    image: "/images/Martin.jpg"
  },
  {
    name: 'Anthony_Joshua',
    DOB: '1991-10-28',
    programme: 'BSc BA',
    level: '300',
    image: "/images/Anthony.jpg"
  },
  {
    name: 'Alex_Love',
    DOB: '1990-04-14',
    programme: 'BSc ICT',
    level: '400',
    image: "/images/love.jpg"
  },
  {
    name: 'Tupac Shakur',
    DOB: '1997-09-18',
    programme: 'BSc MIS',
    level: '200',
    image: "/images/Tupac.jpg"
  },
  {
    name: 'Biggie Smalls',
    DOB: '1995-11-20',
    programme: 'BSc ICT',
    level: '200',
    image: "/images/Biggie.jpg"
  }
 
];


/* GET students listing. */
router.get('/', function(req, res,) {
  res.render('students',{title: 'Students', names});
});
// GET student details
router.get('/:id', (req, res,) => {
  let index = req.params.id
  res.render('details', {title: "student's details", student: names[index]  });
 });
 
module.exports = router;
